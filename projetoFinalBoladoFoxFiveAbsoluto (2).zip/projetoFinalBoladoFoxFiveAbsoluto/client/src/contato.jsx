import "./mainnav.css"
//import img4 from "./components/img/img4.jpg"
import face from "./img/contatos/facebook.png"
import insta from "./img/contatos/instagram.png"
import zap from "./img/contatos/whatsapp.png"
import linkedin from "./img/contatos/linkedin.png"
import logo from "./img/logotipo/logo.jpeg";

import React from "react";
import './App.css';





function Contato() {



  return (
    <div className="container-do-menu-geral">
    <div className="container-do-menu">
       <div className="div1">
       <figure><img className="logo" src={logo}  width="70px" /></figure>
       
       </div>
       <div className="div2">
         <ul id="">
             <li><a href="/">Home</a></li>
             <li><a href="/sobre">Sobre nós</a></li>
             <li><a href="/cadastro">Cadastrar</a></li>
             <li><a href="/contato">Contato</a></li>
         </ul>
         </div>


    </div>

    <h1 class="al2">Contate-nos:</h1>
<center>
    <div class="card-contatos">
           
            <li><figure><a href="https://www.linkedin.com/in/leandro-ariel-714091177/" ><img src={face}  width="70px"/>  </a></figure></li>
            <li><figure><a href="https://www.linkedin.com/in/leandro-ariel-714091177/" ><img src={insta}  width="70px"/>  </a></figure></li>
            <li><figure><a href="https://www.linkedin.com/in/leandro-ariel-714091177/" ><img src={zap}  width="70px"/>  </a></figure></li>
            <li><figure><a href="https://www.linkedin.com/in/leandro-ariel-714091177/" ><img src={linkedin} width="70px" />  </a></figure></li>         
           
        </div>
        </center>


      <br></br>
      <br></br>
      <br></br>
      <br></br>

    
        
  <footer>
			<div class="wrapper">
				<div class="footer-box">
					<div class="company-footer">
          <figure><img className="logo" src={logo}  width="90px" /></figure>
						<h2 className="pt">A EMPRESA</h2>
						<p className="ct">FoxFive.com NOSSO FOCO A FoxFive está sempre empenhada em buscar a satisfação dos seus clientes, oferecendo <br></br>
            produtos e serviços com qualidade e garantia. Preocupada com as novas tendências do mercado tecnológico, busca <br></br>
            soluções e novidades, dispondo sempre dos produtos mais avançados do mercado.</p>
					</div>
				</div>



				<div id="card-footer-ul">
					<div class="card-footer-ul">
						<h2 className="pt">CATEGORIAS</h2>
						<ul class="ul-do-footer">
            <li>
								<a href="/">Home</a>
					
							</li>
							<li>
								<a href="/sobre">Sobre nós</a>
					
							</li>
							<li>
								<a href="/cadastro">Cadastrar</a>
								
							</li>
							<li>
								<a href="/contato">Fale conosco</a>
		
							</li>
						</ul>
					</div>
          <br></br>
          <br></br>
      
				</div>


			</div>



      
			<div class="footer-bottom">
				<div class="wrapper">
					<p>Desenvolvido pela FoxFive</p>
				</div>
			</div>
		</footer>
	</div>



  );
}

export default Contato;
