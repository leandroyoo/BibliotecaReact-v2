import './App.css';
import './mainnav.css';

export function Mainnav(){
    return(
    <div className="menu-nave">
        <ul id="letras-menu">
       <li><a href="/">Home</a></li>
            <li><a href="/sobre">Quem somos nós</a></li>
            <li><a href="/cadastro">Cadastrar</a></li>
            <li><a href="/contato">Contato</a></li>
        </ul>
    </div>
    );
};
