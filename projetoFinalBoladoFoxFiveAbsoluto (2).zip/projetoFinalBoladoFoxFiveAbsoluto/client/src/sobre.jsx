import "./mainnav.css"
//import img4 from "./components/img/img4.jpg"
//import Footer from "./components/footer/Footer.jsx";
import React  from "react";
import './App.css';
import logo from "./img/logotipo/logo.jpeg";

///fundoacima
import fundoSobre from "../src/img/fundos/biblioteca-universitaria.jpg"


///perfil dev
import perfil1 from "./img/perfil/alessandra.jpeg";
import perfil2 from "./img/perfil/ariel01.jpg";
import perfil3 from "./img/perfil/cha.jpeg";
import perfil4 from "./img/perfil/feiao.jpeg";





///programadores
import prog1 from "./img/programadores/programadores1.jpeg"
import prog2 from "./img/programadores/programadores2.jpeg"
import prog3 from "./img/programadores/programadores3.jpeg"


///grafico
import grafico from "./img/grafico/grafico.png"

//explicativo 1 e 2 da regra do negocio

import abc1 from "./img/grafico/em busca de fornecedores.png"

import abc2 from "./img/grafico/fornecedores.png"




function Sobre() {





  return (
    <div className="container-do-menu-geral">
    <div className="container-do-menu">
       <div className="div1">
       <figure><img className="logo" src={logo}  width="70px" /></figure>
       
       </div>
       <div className="div2">
         <ul id="">
             <li><a href="/">Home</a></li>
             <li><a href="/sobre">Sobre nós</a></li>
             <li><a href="/cadastro">Cadastrar</a></li>
             <li><a href="/contato">Contato</a></li>
         </ul>
         </div>


    </div>



<figure><img className="imagem-sobre-fundo" src={fundoSobre} width="100%"   /></figure>




  
      <div id='texto-da-sobre'>
      <h1> Quem somos nós ?</h1>
    <p className="xml">  A origem da livraria Leitura FOX FIVE, começou em 2022, mais especificamente na capital do estado, Rio de Janeiro. Tudo começou em Curso de Programadores Carioca, onde um grupo de jovens estudantes, tiveram a ideia de popularizar a leitura e torná-la mais fácil e acessível.
A ideia era vender livros usados em bom estado de forma Virtual— assim como é a proposta da grande maioria das lojas. A sua localização era através da loja online. O nome original era “Livraria FoxFive”. A pequena livraria em questão foi aumentando até os dias de hoje. Para o grande desenvolvimento da empresa os jovens passaram meses montando o projeto, estudando a necessidade do mercado e utilizando ferramentas que os ajudariam nesta missão.Atualmente, a rede tem atualmente 81 lojas parceiras distribuídas em diversos Estados do Brasil. Apesar dos pesares, a Livraria FOX Five  continua de pé,  o serviço disponibilizado pelo site oficial. E de acordo com a sua visão, o objetivo é continuar crescendo:“Nosso objetivo é ser a melhor loja de entretenimento e informação, nos consolidando como a grande referência do setor. Quanto mais crescermos, mais vamos disseminar essa informação, ajudando as pessoas a construir e viver em um mundo melhor e mais justo. ”
Atualmente, a Livraria Fox Five se dedica a oferecer um espaço multimídia, no qual a busca pelo produto é apenas o início de uma jornada enriquecedora.</p> 
      </div>



  


<div className="imagem-sobre2">
 <h1 className="al2"> Metodologia da FoxFive</h1>
<figure><img className="imagem-sobre-fundo2" src={abc2} width="85%"   /></figure>
</div>


<br></br>
<br></br>


<div className="imagem-sobre2">
<h1 className="al2"> De acordo com os dados </h1>
<figure><img className="imagem-sobre-fundo2" src={grafico} width="85%"   /></figure>
</div>

<br></br>

<br></br>
<br></br>
<br></br>


<div> 
  <h1 className="al">Desenvolvedores</h1>


  <div class="caixaperfils">
  <div class="perfil0">
  
  <figure><img className="logo" src={perfil1} class="ic"   width="300px" height="300px"  /></figure> 
   <p>Alessandra</p>
  </div>

  <div class="perfil2">
  <figure><img className="logo2" src={perfil2} class="ic"   width="300px" height="300px"  /></figure> 
    <p>Leandro</p>
  </div>
  
  <div class="perfil3">
   
  <figure><img className="logo2" src={perfil4} class="ic"  width="300px" height="300px"  /></figure> 
    <p>Eduardo</p>
  </div>
  
  <div class="perfil4">
  
  <figure><img className="logo2" src={perfil3} class="ic"  width="300px" height="300px"  /></figure>
  
    <p>Chayenne</p>
  </div>

  

</div>









</div>

<br></br>
<br></br>
<br></br>

<br></br>
<br></br>
<br></br>
<br></br>
<div> 
  <h1 className="al"> Oque é o programadores Cariocas ? </h1>
    
  <p className="txt">Programadores Cariocas”. Uma parceria do Senac RJ, Resilia e a Prefeitura do Rio de Janeiro.
    A Prefeitura do Rio, por iniciativa do prefeito Eduardo Paes, criou o Programadores Cariocas, para capacitar 5 mil jovens na área de Tecnologia da Informação até 2024.
    O projeto faz parte de um grande ecossistema de iniciativas conectadas, que têm o objetivo de tornar o Rio a capital da Inovação e Tecnologia. Temos muitas universidades, centros de pesquisa e, uma dificuldade que temos é não conseguir levar esse capital humano para os negócios e a geração de economia – comenta Chicão Bulhões, secretário municipal de Desenvolvimento Econômico, Inovação e Simplificação.</p>
   
    <br></br>
<br></br>

   <div className="card-sobre-programador">

   <div>
   <figure><img className="logo" src={prog1} width="200px" /></figure>
    </div>

    <div>
   <figure><img className="logo" src={prog2} width="200px" /></figure>
    </div>

    <div>
   <figure><img className="logo" src={prog3} width="200px" /></figure>
    </div>
    </div>
</div>

<br></br>
<br></br>
<br></br>



<div className="absoluta" width="100%"> 


      
  <footer>
			<div class="wrapper">
				<div class="footer-box">
					<div class="company-footer">
          <figure><img className="logo" src={logo}  width="90px" /></figure>
						<h2 className="pt">A EMPRESA</h2>
						<p className="ct">FoxFive.com NOSSO FOCO A FoxFive está sempre empenhada em buscar a satisfação dos seus clientes, oferecendo <br></br>
            produtos e serviços com qualidade e garantia. Preocupada com as novas tendências do mercado tecnológico, busca <br></br>
            soluções e novidades, dispondo sempre dos produtos mais avançados do mercado.</p>
					</div>
				</div>



				<div id="card-footer-ul">
					<div class="card-footer-ul">
						<h2 className="pt">CATEGORIAS</h2>
						<ul class="ul-do-footer">
            <li>
								<a href="/">Home</a>
					
							</li>
							<li>
								<a href="/sobre">Sobre nós</a>
					
							</li>
							<li>
								<a href="/cadastro">Cadastrar</a>
								
							</li>
							<li>
								<a href="/contato">Fale conosco</a>
		
							</li>
						</ul>
					</div>
          <br></br>
          <br></br>
      
				</div>


			</div>



      
			<div class="footer-bottom">
				<div class="wrapper">
					<p>Desenvolvido pela FoxFive</p>
				</div>
			</div>
		</footer>
	</div>





  
</div>


  );
}

export default Sobre;
