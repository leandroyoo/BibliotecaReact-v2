import {Routes} from "react-router-dom";
import { BrowserRouter as Router} from "react-router-dom"
import Cadastro from "./Form";  ///AQUI É O CADASTRO
import { Route } from "react-router-dom";
import Home1 from "./home1";
import Sobre from "./sobre"
import Contato from './contato'
import './App.css';

export function Approuter(){
    return(
        <Router>
            <Routes>
                <Route path="/" element = {<Home1/>} />
                <Route path="/cadastro" element ={<Cadastro/>}/>
                <Route path="/contato" element ={<Contato/>}/>
                <Route path="/sobre" element ={<Sobre/>}/>
                
            </Routes>
        </Router>
    );
};
