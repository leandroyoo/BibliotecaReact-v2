import React from "react";
import './App.css';
import { Approuter } from "./approuter.jsx";


function App(){
  return(
    <div>
      
      <Approuter/>



    </div>
  );
};

export default App;
