import "./mainnav.css"
//import img4 from "./components/img/img4.jpg"

import logo from "./img/logotipo/logo.jpeg";
import React, { useEffect, useState } from "react";
import './App.css';
import Axios from "axios";
import Card from "./components/cards/cards";


function LimparForm() {
  document.getElementById("name").value = "";
  document.getElementById("developers").value = "";
  document.getElementById("description").value = "";
  document.getElementById("repository").value = "";
  document.getElementById("view").value = "";
}


////principal
function Cadastro() {
  const [values, setValues] = useState();
  const [listCard, setListCard] = useState([]);
  console.log(listCard);
  const handleRegisterGame = () => {
    Axios.post("http://localhost:3001/register", {
      name: values.name,
      developers: values.developers,
      description: values.description,
      category: values.category,
      repository: values.repository,
      view: values.view,
    }).then(() => {
      Axios.post("http://localhost:3001/search", {
        name: values.name,
        developers: values.developers,
        description: values.description,
        category: values.category,
        repository: values.repository,
        view: values.view,
      }).then((response) => {
        setListCard([
          ...listCard,
          {
            id: response.data[0].id,
            name: values.name,
            developers: values.developers,
            description: values.description,
            category: values.category,
            repository: values.repository,
            view: values.view,
          },
        ]);
      });
    });
    LimparForm();
  };

  useEffect(() => {
    Axios.get("http://localhost:3001/getCards").then((response) => {
      setListCard(response.data);
    });
  }, []);

  const handleaddValues = (value) => {
    setValues((prevValues) => ({
      ...prevValues,
      [value.target.name]: value.target.value,
    }));
  };



  return (
    <div className="container-do-menu-geral">
    <div className="container-do-menu">
       <div className="div1">
       <figure><img className="logo" src={logo} width="70px" /></figure>
       
       </div>
       <div className="div2">
         <ul id="">
             <li><a href="/">Home</a></li>
             <li><a href="/sobre">Sobre nós</a></li>
             <li><a href="/cadastro">Cadastrar</a></li>
             <li><a href="/contato">Contato</a></li>
         </ul>
         </div>
 
 
     </div>

    <div className="app-container">
      <div id='titulo'>
        <h1>FoxFive</h1>
        <br/>
        
      </div>
      <h2>Livros Cadastrados</h2>
      <div className="card-grid">
        {listCard.map((val) => (
          <Card
            listCard={listCard}
            setListCard={setListCard}
            key={val.id}
            id={val.id}
            name={val.name}
            developers={val.developers}
            description={val.description}
            category={val.category}
            repository={val.repository}
            view={val.view}
          />
        ))}
      </div>


    </div>
    </div>
  );
}

export default Cadastro;
